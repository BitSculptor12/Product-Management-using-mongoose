"use client"

import  from "../models/Product"

export default function SyntheticV0PageForDeployment() {
  return < />
}